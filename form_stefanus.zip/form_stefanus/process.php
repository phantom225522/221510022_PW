<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "form_db";

// Set charset to UTF-8 to handle special characters
$conn = new mysqli($host, $user, $password, $dbname);
$conn->set_charset("utf8mb4");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$nama = $_POST['nama'];
$nik = $_POST['nik'];
$email = $_POST['email'];
$pesan = $_POST['pesan'];

// Use prepared statement to avoid SQL injection and handle special characters
$stmt = $conn->prepare("INSERT INTO kontak (nama, nik, email, pesan) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $nama, $nik, $email, $pesan);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hasil Pengiriman</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .result-container {
            text-align: center;
            padding: 30px;
        }
        .result-image {
            max-width: 300px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            margin: 20px 0;
        }
        .success-message {
            color: #28a745;
            font-size: 24px;
            font-weight: bold;
            margin: 20px 0;
        }
        .error-message {
            color: #dc3545;
            font-size: 24px;
            font-weight: bold;
            margin: 20px 0;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .back-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="result-container">
            <h1>Stefanus 221510022</h1>
            
            <?php
            if ($stmt->execute()) {
                echo '<img src="Stefanus 2.jpeg" alt="Stefanus" class="result-image">';
                echo '<div class="success-message">✅ Berhasil Dikirim!</div>';
                echo '<p>Data kontak Anda telah berhasil disimpan ke database.</p>';
            } else {
                echo '<div class="error-message">❌ Tidak Berhasil</div>';
                echo '<p>Terjadi kesalahan: ' . $stmt->error . '</p>';
            }
            
            $stmt->close();
            ?>
            
            <a href="index.html" class="back-button">Kembali ke Form</a>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>
