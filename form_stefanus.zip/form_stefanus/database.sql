CREATE DATABASE IF NOT EXISTS form_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE form_db;

CREATE TABLE IF NOT EXISTS kontak (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    nik VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL,
    pesan TEXT NOT NULL,
    waktu TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

INSERT INTO kontak (nama, nik, email, pesan) VALUES
('Andi', '1234567890123456', 'andi@example.com', 'Halo, ini pesan pertama.'),
('Stefanus', '221510022001', 'stefanus@example.com', 'Data baru dari Stefanus 221510022');
